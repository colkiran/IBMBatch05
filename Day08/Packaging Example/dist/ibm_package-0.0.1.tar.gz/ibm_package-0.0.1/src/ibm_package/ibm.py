
gname = "Sunil Gavaskar"

runs = {'odi': 18740, 'test': 14650, 't20': 2150}

sports = {'cricket', 'tennis', 'football', 'badmiton', 'volleyball', 'swimming', 'hockey'}

def greet(gnm):
    print(f"Greetings Mr.{gnm}, Welcome to the event.....")

class Employee:
    def __init__(self, name, salary):
        self.name = name
        self.salary = salary

    def __str__(self):
        return f"Name is {self.name}\nSalary is {self.salary}"

